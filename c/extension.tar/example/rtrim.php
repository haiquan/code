<?php
$current_path = rtrim(dirname(__FILE__), '/');
var_dump($current_path);
$base_path = rtrim(dirname(dirname(__FILE__)), '/');
var_dump($base_path);
