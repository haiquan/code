<?php
class classb {
    function __construct(){
        echo "classb\n";
    }
}
