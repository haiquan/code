<?php
class classa {
    function __construct(){
        echo "classa\n";
    }
}
