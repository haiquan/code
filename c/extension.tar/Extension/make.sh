make
make test
sudo cp ~/code/php/Extension/modules/haiquan.so /usr/lib/php/modules/
sudo service httpd restart
